"""
AL Modullar
Ixtisoslashgan modullar
"""
