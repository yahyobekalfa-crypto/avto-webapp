"""
AL Kutubxona
O'zbekcha standart kutubxona
"""
