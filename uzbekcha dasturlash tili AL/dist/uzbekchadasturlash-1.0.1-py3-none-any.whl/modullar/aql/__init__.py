"""AL Sun'iy Intellekt Moduli"""
from .neyron import *
from .malumot import *
